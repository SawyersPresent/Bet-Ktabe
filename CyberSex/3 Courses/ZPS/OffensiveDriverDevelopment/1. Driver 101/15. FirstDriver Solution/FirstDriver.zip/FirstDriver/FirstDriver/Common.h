#pragma once

struct TheQuestion
{
	int FirstNumber;
	int SecondNumber;
};

struct TheAnswer
{
	int Answer;
};
#include <ntddk.h>
#include "ioctl.h"
#include "Common.h"

void DriverCleanup(PDRIVER_OBJECT DriverObject);
NTSTATUS CreateClose(_In_ PDEVICE_OBJECT DeviceObject, _In_ PIRP Irp);
NTSTATUS DeviceControl(_In_ PDEVICE_OBJECT DeviceObject, _In_ PIRP Irp);

UNICODE_STRING deviceName = RTL_CONSTANT_STRING(L"\\Device\\FirstDriver");
UNICODE_STRING symlink = RTL_CONSTANT_STRING(L"\\??\\FirstDriver");

extern "C"
NTSTATUS
DriverEntry(
	_In_ PDRIVER_OBJECT DriverObject,
	_In_ PUNICODE_STRING RegistryPath)
{
	UNREFERENCED_PARAMETER(RegistryPath);

	DbgPrint("[+] Hello from FirstDriver DriverEntry\n");

	DriverObject->DriverUnload = DriverCleanup;

	DriverObject->MajorFunction[IRP_MJ_CREATE] = CreateClose;
	DriverObject->MajorFunction[IRP_MJ_CLOSE] = CreateClose;
	DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = DeviceControl;
	
	PDEVICE_OBJECT deviceObject;
	NTSTATUS status = IoCreateDevice(
		DriverObject,
		0,
		&deviceName,
		FILE_DEVICE_UNKNOWN,
		0,
		FALSE,
		&deviceObject
	);

	if (!NT_SUCCESS(status))
	{
		DbgPrint("[!] Failed to create Device Object (0x%08X)\n", status);
		return status;
	}
	
	status = IoCreateSymbolicLink(&symlink, &deviceName);

	if (!NT_SUCCESS(status))
	{
		DbgPrint("[!] Failed to create symlink (0x%08X)\n", status);
		IoDeleteDevice(deviceObject);
		return status;
	}

	return STATUS_SUCCESS;
}

NTSTATUS
DeviceControl(
	_In_ PDEVICE_OBJECT DeviceObject,
	_In_ PIRP Irp)
{
	UNREFERENCED_PARAMETER(DeviceObject);

	PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(Irp);
	NTSTATUS status = STATUS_SUCCESS;
	ULONG_PTR length = 0;

	switch (stack->Parameters.DeviceIoControl.IoControlCode)
	{
	case FIRST_DRIVER_IOCTL_TEST:
	{
		DbgPrint("[+] FIRST_DRIVER_IOCTL_TEST called\n");

		if (stack->Parameters.DeviceIoControl.InputBufferLength < sizeof(TheQuestion))
		{
			status = STATUS_BUFFER_TOO_SMALL;
			DbgPrint("[+] STATUS_BUFFER_TOO_SMALL\n");
			break;
		}

		TheQuestion* data = (TheQuestion*)stack->Parameters.DeviceIoControl.Type3InputBuffer;

		if (data == nullptr)
		{
			status = STATUS_INVALID_PARAMETER;
			DbgPrint("[+] STATUS_INVALID_PARAMETER\n");
			break;
		}

		int first = data->FirstNumber;
		int second = data->SecondNumber;
		int result = first * second;

		DbgPrint("[+] %d * %d = %d\n", first, second, result);

		if (stack->Parameters.DeviceIoControl.OutputBufferLength < sizeof(TheAnswer))
		{
			status = STATUS_BUFFER_TOO_SMALL;
			DbgPrint("[+] STATUS_BUFFER_TOO_SMALL\n");
			break;
		}

		TheAnswer* answer = (TheAnswer*)Irp->UserBuffer;

		if (answer == nullptr)
		{
			status = STATUS_INVALID_PARAMETER;
			DbgPrint("[+] STATUS_INVALID_PARAMETER\n");
			break;
		}

		answer->Answer = result;
		length = sizeof(result);

		break;
	}

	default:
		status = STATUS_INVALID_DEVICE_REQUEST;
		DbgPrint("[!] STATUS_INVALID_DEVICE_REQUEST\n");
		break;
	}

	Irp->IoStatus.Status = status;
	Irp->IoStatus.Information = length;

	IoCompleteRequest(Irp, IO_NO_INCREMENT);

	return status;
}

NTSTATUS
CreateClose(
	_In_ PDEVICE_OBJECT DeviceObject,
	_In_ PIRP Irp)
{
	UNREFERENCED_PARAMETER(DeviceObject);

	DbgPrint("[+] Hello from FirstDriver CreateClose\n");

	Irp->IoStatus.Status = STATUS_SUCCESS;
	Irp->IoStatus.Information = 0;

	IoCompleteRequest(Irp, IO_NO_INCREMENT);

	return STATUS_SUCCESS;
}

void
DriverCleanup(
	PDRIVER_OBJECT DriverObject
)
{
	DbgPrint("[+] Hello from FirstDriver DriverUnload\n");

	IoDeleteSymbolicLink(&symlink);
	IoDeleteDevice(DriverObject->DeviceObject);
}
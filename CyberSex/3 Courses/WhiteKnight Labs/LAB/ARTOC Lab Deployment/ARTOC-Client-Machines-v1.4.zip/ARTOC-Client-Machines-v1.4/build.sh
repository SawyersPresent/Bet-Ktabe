terraform init
terraform plan -out "ARTO_CLIENT_MACHINES.tfplan"
terraform apply "ARTO_CLIENT_MACHINES.tfplan"
